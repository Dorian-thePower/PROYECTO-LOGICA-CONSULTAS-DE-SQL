--32. Obtener todos los actores y mostrar las películas en las que han actuado, incluso si algunos actores no han actuado en ninguna película.

SELECT 
    CONCAT("first_name", ' ', "last_name") AS "nombre_actor", --De la tabla de actor, buscamos peliculas y actores 
    "title" AS "pelicula"
FROM actor a
LEFT JOIN film_actor fa ON a.actor_id = fa.actor_id          --Juntamos las tablas actor y film_actor con foreign key actor_id
LEFT JOIN film f ON fa.film_id = f.film_id;                  --Juntamos las tablas film_actor y film con foreign key actor_id