--12. Encuentra el título de las películas en la tabla “film” que no sean ni ‘NC17’ ni ‘G’ en cuanto a su clasificación.

SELECT "title" 
FROM "film" 
WHERE "rating" NOT IN ('NC-17', 'G');