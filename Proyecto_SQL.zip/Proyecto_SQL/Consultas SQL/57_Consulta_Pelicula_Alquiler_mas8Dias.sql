--57. Encuentra el título de todas las películas que fueron alquiladas por más de 8 días.                                              

SELECT 
     "title" AS "titulo_pelicula",                                                    --Seleccionamos por titulo de pelicula, fecha de alquiler y fecha de devolución
     "rental_date" AS "fecha_alquiler",
     "return_date" AS "fecha_devolucion" 
FROM film f                                                                           --De la tabla film     
INNER JOIN inventory i ON f.film_id = i.film_id                                       --Conectamos la tabla film y inventory
INNER JOIN rental r ON i.inventory_id = r.inventory_id                                --Conectamos la tabla inventory y rental
WHERE DATE_PART('day', "return_date" - "rental_date") > 8;                            --Filtramos por la diferencia de fecha_devolucion y fecha_alquiler mayor a 8 días