--15. ¿Cuánto dinero ha generado en total la empresa?

SELECT 
    SUM("amount") AS "total_importe"
FROM "payment";
