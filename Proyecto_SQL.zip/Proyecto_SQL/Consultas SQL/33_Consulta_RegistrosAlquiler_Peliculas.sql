--33. Obtener todas las películas que tenemos y todos los registros de alquiler.

SELECT                                                       --De la tabla de film, buscamos mediante left joins los registros de alquiler por pelicula
    f.film_id,
    "title",
    "rental_id",
    "rental_date",
    "return_date",
    "customer_id"
FROM film f 
LEFT JOIN inventory i ON f.film_id = i.film_id              --Juntamos las tablas film y inventory con foreign key film_id
LEFT JOIN rental r ON i.inventory_id = r.inventory_id;      --Juntamos las tablas inventory y rental con foreign key inventory_id