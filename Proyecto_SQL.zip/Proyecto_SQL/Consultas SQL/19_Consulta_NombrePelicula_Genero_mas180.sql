--19. Encuentra el título de las películas que son comedias y tienen una duración mayor a 180 minutos en la tabla “filmˮ.

SELECT f.title AS "titulo_pelicula"                                  --Seleccionamos por titulo de pelicula
FROM film f                                                          --De la tabla film
   INNER JOIN film_category fc ON f.film_id = fc.film_id             --Buscamos el valor (foreign key) de film_id entre tablas de film_category y film y conectamos ambas tablas
   INNER JOIN category c  ON c.category_id = fc.category_id          --Buscamos el valor (foreign key) de category_id entre las tablas de film_category y category
WHERE c."name" = 'Comedy'                                            --Filtramos por nombre Comedy de la tabla category y duración mayor de 180 min. de la tabla de film
   AND  "length" > 180;   