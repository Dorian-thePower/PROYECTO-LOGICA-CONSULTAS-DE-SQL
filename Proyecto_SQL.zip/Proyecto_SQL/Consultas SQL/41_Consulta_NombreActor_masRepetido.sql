--41. Agrupa los actores por su nombre y cuenta cuántos actores tienen el mismo nombre. ¿Cuál es el nombre más repetido?

SELECT 
     "first_name" AS "nombre_actor",                  --De la tabla actor, seleccionamos nombre y contamos por actor_id
     count("actor_id") AS "cantidad_nombre"
FROM "actor"
GROUP BY "nombre_actor"                                 --Agrupamos por nombre de actor
HAVING count(actor_id) > 1                            --Filtramos la consulta solo para aquellos nombres que aparecen repetidos
ORDER BY "cantidad_nombre" DESC;                      --Ordenamos por el resultado el conteo (cantidad) de forma descendiente
                                                      --El nombre mas repetido es "Penelope", "Kenneth" y"Julia"