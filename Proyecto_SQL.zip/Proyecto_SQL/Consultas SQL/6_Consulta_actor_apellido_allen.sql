--6. Encuentra el nombre y apellido de los actores que tengan ‘Allenʼ en su apellido.

SELECT "first_name", "last_name" 
FROM "actor"  
WHERE "last_name" ='Allen';