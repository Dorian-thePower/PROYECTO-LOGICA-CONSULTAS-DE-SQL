-- 58. Encuentra el título de todas las películas que son de la misma categoría que ‘Animationʼ.

SELECT  
     "title" AS "pelicula",                                                           --Seleccionamos pelicula y categoria
     "name"  AS "categoria"
FROM film f                                                                           --De la tabla film
INNER JOIN film_category fc ON f.film_id = fc.film_id                                 --Conectamos la tabla film y film_category
INNER JOIN category c ON fc.category_id = c.category_id                               --Conectamos la tabla film_category y category
WHERE c."name"  = 'Animation';                                                         --Filtramos peliculas por c.name (categoria) que es igual a 'Animation'