--28. Muestra el id de los actores que hayan participado en más de 40 películas

SELECT fa.actor_id ,
       count(fa.film_id ) AS "total_peliculas"  --De la tabla de film_actor. seleccionamos actor_id y total de film_id
FROM film_actor fa 
GROUP BY fa.actor_id                            --Agrupamos por actor_id y mostramos el total de actores en mas de 40 peliculas
HAVING count(fa.film_id ) > 40;