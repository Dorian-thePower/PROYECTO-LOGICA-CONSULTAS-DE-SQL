--42. Encuentra todos los alquileres y los nombres de los clientes que los realizaron.

SELECT
     "rental_id",                                            --Seleccionamos todos los alquileres con su id y fecha, mas los nombres de los clientes
     "first_name" AS "nombre",
     "last_name" AS "apellido",
     "rental_date" AS "fecha_alquiler"                              
FROM rental r                                                --De la tabla rental
INNER JOIN customer c ON r.customer_id = r.customer_id;       --Junto con la tabla customer mediante un join