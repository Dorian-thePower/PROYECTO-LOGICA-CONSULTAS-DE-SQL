--25. Averigua el número de alquileres registrados por mes

SELECT 
    EXTRACT(MONTH FROM "rental_date") AS mes,  --Extraemos mes del formato de fecha de alquiler de la tabla de rental
    COUNT(*) AS "numero_alquileres"            -- Contamos el total de alquileres
FROM "rental"
GROUP BY "mes"                                 --Agrupamos y ordenamos el núnero de alquilieres por mes
ORDER BY "mes" ;
