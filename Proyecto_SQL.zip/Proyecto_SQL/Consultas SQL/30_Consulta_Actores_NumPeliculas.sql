--30. Obtener los actores y el número de películas en las que ha actuado.

SELECT 
     concat(a.first_name ,' ', a.last_name) AS "nombre_actores",
     count(fa.film_id) AS "numero_peliculas"                   --De la tabla de actor, contamos el total de peliculas por cada actor
FROM actor a 
INNER JOIN film_actor fa ON a.actor_id = fa.actor_id           --Juntamos tablas actor con film_actor para relacionar actores con películas.
GROUP BY "nombre_actores"                                      --Agrupamos por actor