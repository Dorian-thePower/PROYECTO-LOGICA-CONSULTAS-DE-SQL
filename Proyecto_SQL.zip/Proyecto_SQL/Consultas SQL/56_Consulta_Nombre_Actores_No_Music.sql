--56. Encuentra el nombre y apellido de los actores que no han actuado en ninguna película de la categoría ‘Musicʼ.
                                    
SELECT 
    "first_name" AS "nombre",                                                         --Selecciomamos nombre y apellido
    "last_name" AS "apellido"
FROM actor a                                                                          --De la tabla actor
WHERE a.actor_id NOT IN (                                                             --Reliazamos subconsulta, filtrando por actor_id, que no esta
    SELECT fa.actor_id                                                                --En la selección de actor_id 
    FROM film_actor fa                                                                --De la tabla film_actor
    INNER JOIN film f ON fa.film_id = f.film_id                                       --Conectamos tabla film_actor y film
    INNER JOIN film_category fc ON f.film_id = fc.film_id                             --Conectamos tabla film y folm_category
    INNER JOIN category c ON fc.category_id = c.category_id                           --Conectamoos tabla film_category y category
    WHERE c.name = 'Music'                                                            --Filtramos por c.name (categoria) igual a 'Music'
)
ORDER BY "nombre" ASC;                                                                --Ordenamos por nombre de forma ascendiente