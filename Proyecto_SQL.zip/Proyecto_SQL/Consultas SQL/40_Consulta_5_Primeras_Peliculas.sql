--40. Selecciona las primeras 5 películas de la tabla “filmˮ.

SELECT "title" 
FROM "film" 
ORDER BY "film_id" ASC 
LIMIT 5;