--17. Encuentra el nombre y apellido de los actores que aparecen en la película con título ‘Egg Igbyʼ.

SELECT 
     concat(a.first_name, ' ', a.last_name ) AS "nombre_actor",                         --Seleccionamos por nombre completo de actor y titulo de pelicula
     "title"
FROM actor a                                                                            --De la tabla actor
INNER JOIN "film_actor" ON a.actor_id = film_actor.actor_id                             --Contectamos las tablas actor y film_actor
INNER JOIN "film" ON film.film_id = film_actor.film_id                                  --Conectamos las tablas film_actor y film
WHERE "title" = ('Egg Igby');                                                           --Filtrampo por titulo 'Egg Igby

/*Comentario: La búsqueda con estos valores no da resultados. 
  Motivo: el titulo indicado esta en minúsculas 'Egg Igby', mientras que el titulo original esta en mayúsculas 'EGG IGBY'.*/