--26. Encuentra el promedio, la desviación estándar y varianza del total pagado.

SELECT 
    AVG("amount") AS "promedio_tot._pagado",
    STDDEV("amount") AS "desviación_estandar_tot._pagado",
    VARIANCE("amount") AS "varianza_tot._pagado"
FROM "payment";
