--61. Encuentra la cantidad total de películas alquiladas por categoría y muestra el nombre de la categoría junto con el recuento de alquileres.

SELECT 
    "name" AS "categoria",                                                       --Seleccionamos por categoria y total de alquileres
    COUNT("rental_id") AS "total_alquileres"
FROM category c                                                                  --De la tabla category
INNER JOIN film_category fc ON c.category_id = fc.category_id                    --Conectamos tablas de category y film_category
INNER JOIN film f ON fc.film_id = f.film_id                                      --Conectamos tablas de film_category y film
INNER JOIN inventory i ON f.film_id = i.film_id                                  --Conectamos tablas de film e inventory
INNER JOIN rental r ON i.inventory_id = r.inventory_id                           --Conectamos tablas de inventory y rental
GROUP BY "categoria"                                                             --Agrupamos por categoria
ORDER BY "total_alquileres" DESC;                                                  --Ordenamos el total de alquileres por orden descendiente