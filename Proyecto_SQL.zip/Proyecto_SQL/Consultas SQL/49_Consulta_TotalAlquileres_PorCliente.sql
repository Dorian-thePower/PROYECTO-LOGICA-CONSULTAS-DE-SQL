-49. Calcula el número total de alquileres realizados por cada cliente.

SELECT
     "first_name" AS "nombre",                                              --Seleccionamos nombre, apellido y total alquileres
     "last_name" AS "apellido",
     count(r.rental_id ) AS "total_alquiler"
FROM customer c                                                             --De la tabla de customer
LEFT JOIN rental r ON c.customer_id = r.customer_id                         --Conectamos hacia la izquierda la tabla de customer y rental
GROUP BY c.customer_id                                                      --Agrupamos por customer_id
ORDER BY "nombre" , "apellido";                                        --Ordenamos por nombre y apellido