--27. ¿Qué películas se alquilan por encima del precio medio?

SELECT "title" AS "peliculas",
       "rental_rate" AS "precio_alquiler" --De la tabla film seleccionamos las peliculas y el precio de alquler
FROM "film" 
WHERE "rental_rate" > (                   --Mediante subconsulta filtramos aquellas pelicules aluiladas por encima del precio medio
    SELECT AVG("rental_rate")
    FROM "film" 
);