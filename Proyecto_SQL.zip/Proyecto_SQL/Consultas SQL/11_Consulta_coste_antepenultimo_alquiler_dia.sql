--11. Encuentra lo que costó el antepenúltimo alquiler ordenado por día.

SELECT 
     "amount" AS "coste",                                                       --Seleccionamos conste y fecha de alquiler
     "rental_date" AS "fecha_alquiler" 
FROM "payment"                                                                  --De la tabla payment
INNER JOIN "rental" ON rental.rental_id  = payment.rental_id                    --Conectamos a tabla payment con rental
ORDER BY "fecha_alquiler" DESC                                                  --Ordenamos por fecha alquiler de forma descendente
LIMIT 1                                                                         --Devolvemos el antepenúltimo
OFFSET 2;                                                                       --Saltamos el último y penúltimo