/*--20. Encuentra las categorías de películas que tienen un promedio de duración superior a 110 minutos 
y muestra el nombre de la categoría junto con el promedio de duración.*/

SELECT 
     "name" AS "categoria_pelicula" ,                                                     -Seleccionamos categoria de pelicula y su promedio de duración
      AVG("length") AS "promedio_duracion"
FROM category                                                                             --De la tabla category
   INNER JOIN film_category fc ON category.category_id = fc.category_id                   --Conectamos tablas category y film_category
   INNER JOIN film f ON f.film_id = fc.film_id                                            --Conectamos tablas film_category y film
GROUP BY "categoria_pelicula"                                                             --Agrupamos datos por categorias de peliculas
HAVING AVG("length") > 110;                                                               --Filtramos las categorias con el promedio de duración superior a 110 minutos