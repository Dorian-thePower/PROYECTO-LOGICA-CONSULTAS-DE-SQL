--47. Selecciona el nombre de los actores y la cantidad de películas en las que han participado.

SELECT                                                            --Seleccionamos el nombre, apellido y total de peliculas
     "first_name" AS "nombre", 
     "last_name" AS "apellido",
      count(film_id ) AS "total_peliculas"                        --Contamos el total de peliculas por actor
FROM actor a                                                      --De la tabla actor
LEFT JOIN film_actor ON a.actor_id = film_actor.actor_id          --Conectamos hacia la izquierda la tabla actor y film_actor
GROUP BY "nombre", "apellido"                               --Agrupamos por nombre, apellido
ORDER BY "nombre";                                            --Ordenamos por nombre