--37. Encuentra el ID del actor más bajo y más alto en la tabla actor.

SELECT 
     MIN("actor_id") AS "Id_actor_bajo",
     MAX("actor_id") AS "Id_actor_alto"
FROM "actor";