--23. Números de alquiler por día, ordenados por cantidad de alquiler de forma descendente.

SELECT 
      DATE ("rental_date") AS "dia_alquiler",     --Buscamos el dia, en formato sin horas
      COUNT (*) AS "numero_alquileres"            --Contamos el número total de alquileres desde la tabla 'rental'
FROM "rental"                                     --De la tabla rental
GROUP BY DATE("rental_date")                      --Agrupamos por dia de alquiler
ORDER BY "numero_alquileres" ASC;                 --Ordenamos el número de alquiler por dia de forma ascendente