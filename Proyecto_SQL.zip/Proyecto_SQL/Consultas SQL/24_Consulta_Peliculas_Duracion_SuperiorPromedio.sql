--24. Encuentra las películas con una duración superior al promedio.

SELECT 
    title,      --De la tabla de film seleccionamos el nombre y duración de peliculas
    length
FROM film
WHERE length >  --Mediante subconsulta filtramos aquellas pelicules con duración superior al promedio
(
    SELECT AVG(length)
    FROM film
);