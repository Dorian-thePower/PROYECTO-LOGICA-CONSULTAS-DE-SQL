--50. Calcula la duración total de las películas en la categoría 'Action'.

SELECT 
     "name" AS "categoria",                                                 --Seleccionamos la suma de duración total de categoria de pelicula 'Action'
      SUM(f.length) AS "duracion_total"
FROM film f                                                                 --De la tabla film
INNER JOIN film_category fc  ON f.film_id = fc.film_id                      --Conectamos tablas film y film_category
INNER JOIN category c ON fc.category_id = c.category_id                     --Conectamos tablas film_category y category 
WHERE c."name" = 'Action'                                                   --Filtramos por nombre de categoria 'Action'
GROUP BY c."name";                                                          --Agrupamos por categoria