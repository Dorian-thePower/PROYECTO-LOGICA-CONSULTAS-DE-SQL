--16. Muestra los 10 clientes con mayor valor de id.

SELECT  
    "customer_id",
    "first_name",
    "last_name"
FROM "customer"
ORDER BY "customer_id" DESC
LIMIT 10;