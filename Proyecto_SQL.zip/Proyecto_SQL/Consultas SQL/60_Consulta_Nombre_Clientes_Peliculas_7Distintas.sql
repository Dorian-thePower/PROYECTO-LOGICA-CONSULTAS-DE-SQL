--60. Encuentra los nombres de los clientes que han alquilado al menos 7 películas distintas. Ordena los resultados alfabéticamente por apellido.

SELECT 
     "first_name" AS "nombre",                                                   --Seleccionamos por nombre, apellido y peliculas con id distinto
     "last_name" AS "apellido",
     count(DISTINCT f.film_id ) AS "peliculas_distintas"                         
FROM customer c                                                                  --De la tabla de customer
INNER JOIN rental r ON c.customer_id = r.customer_id                             --Conectamos tablas customer y rental
INNER JOIN inventory i ON r.inventory_id = i.inventory_id                        --Conectamos tablas rental y inventory
INNER JOIN film f ON i.film_id = f.film_id                                       --Conectamos tablas inventory y film
GROUP BY "nombre", "apellido"                                                    --Agrupamos por nombre y apellido
HAVING count(DISTINCT f.film_id) >= 7                                            --Filtramos por al menos 7 peliculas distintas
ORDER BY "apellido" ASC;                                                         --Ordenamos alfabéticamente por apellido