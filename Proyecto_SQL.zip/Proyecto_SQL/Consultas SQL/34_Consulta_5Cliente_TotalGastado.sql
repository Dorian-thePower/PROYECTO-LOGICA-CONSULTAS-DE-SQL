--34. Encuentra los 5 clientes que más dinero se hayan gastado con nosotros.

SELECT                                                        --De la tabla de customer, buscamos mediante join los clientes y total gastado
     concat(c.first_name , ' ', c.last_name) AS "cliente", 
     SUM("amount") AS "total_gastado"
FROM customer c 
INNER JOIN payment p ON c.customer_id = p.customer_id       
GROUP BY c.customer_id                                        --Agrupamos por customer
ORDER BY SUM("amount") DESC                                   --Ordenamos por descendiente
LIMIT 5;                                                      --Limitamos la selección para mostrar los 5 clientes con mas importe gastado