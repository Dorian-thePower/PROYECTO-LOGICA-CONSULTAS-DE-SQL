--31. Obtener todas las películas y mostrar los actores que han actuado en ellas, incluso si algunas películas no tienen actores asociados.

SELECT                                                          
     "title",                                                    
     concat("first_name", ' ', "last_name") AS "nombre_actores"   --De la tabla de actor, buscamos peliculas y nombre de actores 
FROM actor a 
FULL JOIN film_actor fa ON a.actor_id = fa.actor_id             --Juntamos las tablas actor y film_actor con foreign key actor_id
FULL JOIN film f ON fa.film_id = f.film_id;                     --Juntamos las tablas film_actor y film con foreign key film_id