--7. Encuentra la cantidad total de películas en cada clasificación de la tabla “film” y muestra la clasificación junto con el recuento.

SELECT "rating", 
        count("film_id") AS "total_peliculas"  
FROM "film"                                                                                --De la tabla film (pelicula)                                         
GROUP BY "rating"                                                                          --Se agrupa por rating (clasificación)
ORDER BY total_peliculas;                                                                  --Se ordena por alias de total_peliculas
