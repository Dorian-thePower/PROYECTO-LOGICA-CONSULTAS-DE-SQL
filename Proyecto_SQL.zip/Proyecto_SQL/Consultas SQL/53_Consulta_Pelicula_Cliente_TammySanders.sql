--53. Encuentra el título de las películas que han sido alquiladas por el cliente con el nombre ‘Tammy Sandersʼ y que aún no se han devuelto. Ordena los resultados alfabéticamente por título de película.

SELECT 
    concat(c.first_name , ' ', c.last_name) AS "nombre_cliente",
    f.title AS "pelicula",
    r.return_date AS "fecha_devolucion"
FROM customer c                                                                      --De la tabla customer
INNER JOIN rental r ON c.customer_id = r.customer_id                                 --Conectamos tablas customer y rental
INNER JOIN inventory i ON r.inventory_id = i.inventory_id                            --Conectamos tablas rental e inventory                                                               
INNER JOIN film f ON i.film_id = f.film_id                                           --Concectamos tablas invetory y film
WHERE concat("first_name" , ' ', "last_name") = 'TAMMY SANDERS' AND "return_date" IS NULL      --Filtramos nombre y apelido del cliente Tammy Sanders (mayúsculas) sin fecha de devolución
ORDER BY "title" ASC;                                                                          --Ordenamos por nombre de pelicula de forma ascendente en orden alfabético.
