--18. Selecciona todos los nombres de las películas únicos.

SELECT DISTINCT "title" AS "nombre_pelicula" 
FROM "film";