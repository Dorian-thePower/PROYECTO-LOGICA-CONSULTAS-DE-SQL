--3.  Encuentra los nombres de los actores que tengan un “actor_idˮ entre 30 y 40

SELECT "first_name", "last_name", "actor_id" 
FROM "actor" 
WHERE "actor_id" BETWEEN 30 AND 40;