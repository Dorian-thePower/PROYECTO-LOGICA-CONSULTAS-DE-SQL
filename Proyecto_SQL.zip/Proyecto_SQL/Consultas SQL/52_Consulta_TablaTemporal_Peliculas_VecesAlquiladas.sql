--52. Crea una tabla temporal llamada “peliculas_alquiladasˮ que almacene las películas que han sido alquiladas al menos 10 veces.

WITH peliculas_alquiladas AS (
   SELECT                                                                          --Seleccionamos titulo de pelicula y contamos las veces de aqluiler
        "title" AS "pelicula",
        COUNT(r.rental_id) AS "veces_alquilada"
   FROM film f                                                                     --De la tabla film
   INNER JOIN inventory i ON f.film_id  = i.film_id                                --Conectamos tablas film e inventory
   INNER JOIN rental r ON i.inventory_id = r.inventory_id                          --Conectamos tablas inventory y rental
   GROUP BY "pelicula"                                                                --Agrupamos por pelicula
   HAVING count(r.rental_id) >= 10                                                 --Filtramos por veces de alquiler mayor o igual a 10
)                                                                                  --Se crea la tabla temporal
SELECT 
     "pelicula",                                                                   --Seleccionamos las columnas creadas
     "veces_alquilada"
FROM peliculas_alquiladas                                                          --De la tabla temporal
ORDER BY "veces_alquilada" ASC;                                                    --Ordenamos por las veces de alquiler de forma ascendiente