--45. Encuentra los actores que han participado en películas de la categoría 'Action'.

SELECT 
    "first_name" AS "nombre",                                      --Selecionamos nombre, apellido y categoria
    "last_name" AS "apellido",
    "name" AS "categoria"
FROM actor a                                                       --De la tabla actor
LEFT JOIN film_actor fa ON a.actor_id = fa.actor_id                --Relacionamos hacia la izquierda la tabla actor con film_actor
RIGHT JOIN film f ON f.film_id  = fa.film_id                       --Relacionamos hacia la derecha la tabla film_actor con film_category
LEFT JOIN film_category fc ON f.film_id = fc.film_id               --Relacionamos hacia la izquierda la tabla actor con film_actor
RIGHT JOIN category c ON c.category_id = fc.category_id            --Relacionamos hacia la derecha la tabla film_category con category
WHERE c."name" = 'Action'                                          --Filtramos por el nombre de categoria 'Action'
GROUP BY "nombre", "apellido", "categoria"                         --Agrupamos por nombre, apellido y categoria
ORDER BY "nombre" ;                                                --Ordenamos por nombre