--63. Obtén todas las combinaciones posibles de trabajadores con las tiendas que tenemos.

SELECT 
     "staff_id" AS "id_trabajador",                                                --Seleccionamos por id_trabajador, nombre, apellido y id_tienda
     "first_name" AS "nombre",
     "last_name" AS "apellido",
     st.store_id AS "id_tienda"
FROM "staff"                                                                       --De la tabla trabajador
CROSS JOIN store st ;                                                              --Combinamos tablas staff y store