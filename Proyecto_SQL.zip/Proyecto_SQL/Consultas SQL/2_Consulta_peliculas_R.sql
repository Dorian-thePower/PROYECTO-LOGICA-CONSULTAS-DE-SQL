--2. Muestra los nombres de todas las películas con una clasificación por edades de ‘Rʼ.

SELECT "title", "rating" 
FROM "film"  
WHERE "rating" = 'R';