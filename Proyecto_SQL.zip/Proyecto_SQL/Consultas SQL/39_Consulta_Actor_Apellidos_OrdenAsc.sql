--39. Selecciona todos los actores y ordénalos por apellido en orden ascendente.

SELECT 
     "first_name" AS "nombre" , 
     "last_name" AS "apellido"
FROM "actor"
ORDER BY "apellido" ASC;