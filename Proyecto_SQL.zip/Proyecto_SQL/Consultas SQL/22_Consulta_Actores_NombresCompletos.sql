--22. Crea una columna con el nombre y apellidos de todos los actores y actrices.

SELECT concat("first_name", ' ', "last_name") AS "nombre_completo"
FROM actor;