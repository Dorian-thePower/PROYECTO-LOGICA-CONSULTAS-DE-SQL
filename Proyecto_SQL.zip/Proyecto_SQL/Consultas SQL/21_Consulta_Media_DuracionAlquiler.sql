--21. ¿Cuál es la media de duración del alquiler de las películas?

SELECT AVG("rental_duration") AS "media_duracion_alquiler"
FROM "film" ;