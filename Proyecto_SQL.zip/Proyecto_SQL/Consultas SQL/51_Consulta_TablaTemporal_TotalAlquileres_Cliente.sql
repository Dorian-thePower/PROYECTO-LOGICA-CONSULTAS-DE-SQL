--51. Crea una tabla temporal llamada “cliente_rentas_temporalˮ para almacenar el total de alquileres por cliente.


WITH cliente_rentas_temporal AS (
    SELECT                                                          --Seleccionamos nombre, apellido y total de alquileres por cliente
        "first_name" AS "nombre",
        "last_name" AS "apellido",
        COUNT(r.rental_id) AS "total_alquileres"
    FROM customer c                                                 --De la tabla customer
    LEFT JOIN rental r ON c.customer_id = r.customer_id             --Relacionamos hacia la izquierda la tabla customer con rental
    GROUP BY "nombre", "apellido"                                   --Agrupamos por nombre y apellido
)                                                                   --Termina de crearse la tabla temporal
SELECT 
    "nombre",                                                       --Seleccionamos las columnas creadas
    "apellido",
    "total_alquileres"
FROM cliente_rentas_temporal                                        --De la tabla temporal
ORDER BY "total_alquileres" DESC;                                   --Ordenamos por total de alquileres de forma descendiente