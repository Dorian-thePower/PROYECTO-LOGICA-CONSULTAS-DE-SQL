--64. Encuentra la cantidad total de películas alquiladas por cada cliente y muestra el ID del cliente, su nombre y apellido junto con la cantidad de películas alquiladas.

SELECT 
     c.customer_id AS "id_cliente",                                                 --Seleccionamos por id_cliente, nombre, apellido y recuento de total peliculas
     "first_name" AS "nombre",
     "last_name" AS "apellido",
     count(r.rental_id) AS "total_peliculas"
FROM customer c                                                                     --De la tabla de customer
INNER JOIN rental r ON c.customer_id = r.customer_id                                --Conectamos tablas customer y rental
GROUP BY "nombre", "apellido", "id_cliente" ;                                       --Agrupamos por nombre, apellido e id_cliente