--9. Encuentra la variabilidad de lo que costaría reemplazar las películas

SELECT 
     AVG("replacement_cost") AS "coste_promedio",
     STDDEV("replacement_cost") AS "desviacion_estandar",
     VARIANCE("replacement_cost") AS "varianza"   
FROM "film";