--5. Ordena las películas por duración de forma ascendente.

SELECT "title", "length" as "duracion_peliculas" 
FROM "film"
ORDER BY "length" ASC;