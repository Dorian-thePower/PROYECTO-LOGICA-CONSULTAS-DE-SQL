-- 35. Selecciona todos los actores cuyo primer nombre es 'Johnny'.

SELECT * 
FROM actor a 
WHERE a.first_name = 'JOHNNY';