--46. Encuentra todos los actores que no han participado en películas

SELECT 
    a.actor_id,                                                     --Selecionamos actor_id, nombre, apellido y film_id
    "first_name" AS "nombre",
    "last_name" AS "apellido",
     fa.film_id 
FROM actor a                                                       --De la tabla actor
LEFT JOIN film_actor fa ON a.actor_id = fa.actor_id                --Relacionamos hacia la izquierda la tabla actor con film_actor                                
WHERE fa.film_id IS NULL                                           --Filtramos por film_id que es Null
ORDER BY a.actor_id;                                               --Ordenamso por actor_id