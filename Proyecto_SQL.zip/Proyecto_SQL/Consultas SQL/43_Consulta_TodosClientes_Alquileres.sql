--43 Muestra todos los clientes y sus alquileres si existen, incluyendo aquellos que no tienen alquileres.

SELECT
     "first_name" AS "nombre",                                           --Seleccionamos nombre, apellidos y cuenta de alquiler
     "last_name" AS "apeliido",
     "rental_id" AS "cuenta_alquiler"
FROM rental r                                                             --De la tabla rental
RIGHT JOIN customer c ON c.customer_id = r.customer_id                    --Conectamos hacia la derecha la tabla rental y customer
ORDER BY "cuenta_alquiler";                                                     --Ordenamos por cuenta de alquiler