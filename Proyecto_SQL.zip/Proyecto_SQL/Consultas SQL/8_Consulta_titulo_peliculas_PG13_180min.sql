--8. Encuentra el título de todas las películas que son ‘PG-13’ o tienen una duración mayor a 3 horas en la tabla film.

SELECT "title" 
FROM "film"
WHERE "rating" = 'PG-13' OR "length" > 180;