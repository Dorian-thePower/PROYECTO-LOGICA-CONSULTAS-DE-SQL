--59. Encuentra los nombres de las películas que tienen la misma duración que la película con el título ‘Dancing Feverʼ. Ordena los resultados alfabéticamente por título de película.

SELECT 
     "title" AS "pelicula",  
     "length" AS "duracion"
FROM "film"                                                                    --De la tabla film
WHERE "length" = (                                                             --Realizamos subconsulta, filtrando la duración que es igual
    SELECT                                                                     
         "length"                                                              --Seleccionando la duración
    FROM "film"                                                                --De la tabla film
    WHERE "title" = 'DANCING FEVER'                                            --Filtrando la pelicula que es igual a 'DANCING FEVER' en mayúsculas para obtener resultados
)
ORDER BY "title" ASC;                                                          --Ordenamos por titulo de pelicula de forma alfabética    