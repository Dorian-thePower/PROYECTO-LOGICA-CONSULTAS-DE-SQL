--44. Realiza un CROSS JOIN entre las tablas film y category. ¿Aporta valor esta consulta? ¿Por qué? Deja después de la consulta la contestación.

SELECT f.title , c."name" 
FROM film f
CROSS JOIN category c ;

/*No aperota valor, porque cross join esta mostrando valores de peliculas que no tienen relación con el genero mostrado. 
 Para mostrar las combinaciones que dan resultados reales se deben relacionar las tablas de film y category a través de la tabla intermedia de film_category.
 */