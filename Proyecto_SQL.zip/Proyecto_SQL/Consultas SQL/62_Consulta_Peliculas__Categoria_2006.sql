--62. Encuentra el número de películas por categoría estrenadas en 2006.

SELECT 
     c."name" AS "categoria",                                                     --Seleccionamos categoria y recuento total de peliculas 
     count(f.film_id) AS "total_peliculas"
FROM film f                                                                       --De la tabla film
INNER JOIN film_category fc ON f.film_id = fc.film_id                             --Conectamos tablas film y film_category
INNER JOIN category c ON fc.category_id = c.category_id                           --Conectamos tablas film_category y category
WHERE f.release_year = 2006                                                       --Filtramos por fecha de estreno de peliculas igual a 2006
GROUP BY c."name"                                                                 --Agrupamos por c.name (categoria)
ORDER BY "total_peliculas" DESC;                                                  --Ordenamos por total_peliculas de forma descendiente