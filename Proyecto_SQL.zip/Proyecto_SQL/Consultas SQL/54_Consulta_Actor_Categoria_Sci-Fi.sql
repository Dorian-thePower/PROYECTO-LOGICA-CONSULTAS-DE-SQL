--54. Encuentra los nombres de los actores que han actuado en al menos una película que pertenece a la categoría ‘Sci-Fiʼ. Ordena los resultados alfabéticamente por apellido.

SELECT 
     "first_name" AS nombre,                                                     --Seleccionamos nombre, apellido y categoria
     "last_name" AS apellido,
     "name" AS "categoria"
FROM actor a                                                                     --De la tabla actor
INNER JOIN film_actor fa ON a.actor_id = fa.actor_id                             --Conectamos tabla actor y film_actor
INNER JOIN film f ON fa.film_id = f.film_id                                      --Conectamos tabla film_actor y film
INNER JOIN film_category fc ON f.film_id = fc.film_id                            --Conectamos tabla film y film_category
INNER JOIN category c ON fc.category_id = c.category_id                          --Conectamos tabla fil_category y category
WHERE "name" = 'Sci-Fi'                                                          --Filtramos por categoria 'Sci-Fi'
GROUP BY "nombre", "apellido", "categoria"                                       --Agrupamos por nombre, apellido y categoria
ORDER BY "apellido" ASC;                                                         --Ordenamos por apellido por orden alfabético