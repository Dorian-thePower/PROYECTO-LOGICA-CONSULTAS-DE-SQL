--55. Encuentra el nombre y apellido de los actores que han actuado en películas que se alquilaron después de que la película ‘Spartacus Cheaperʼ se alquilara por primera vez. Ordena los resultados alfabéticamente por apellido.


SELECT DISTINCT                                                                       --Seleccionamos nombre y apellidos distintos a los resultados de subconsulta
    "first_name" AS "nombre",
    "last_name" AS "apellido"
FROM actor a                                                                          --De la tabla actor
INNER JOIN film_actor fa ON a.actor_id = fa.actor_id                                  --Conectamos tabla actor y film_actor
INNER JOIN film f ON fa.film_id = f.film_id                                           --Conectamos tabla film_actor y film
INNER JOIN inventory i ON f.film_id = i.film_id                                       --Conectamos tabla film y inventory
INNER JOIN rental r ON i.inventory_id = r.inventory_id                                --Connectamos tabla inventory y rental
WHERE "rental_date" >                                                                 --Realizamos subconsulta, filtrando por la fecha de alquiler mayor 
      (
        SELECT MIN(r2.rental_date)                                                    --A la primera fecha de alquiler seleccionada de la pelicula 'Spartacus Cheap'
        FROM rental r2                                                                --De la tabla rental
        INNER JOIN inventory i2 ON r2.inventory_id = i2.inventory_id                        --Conectamos tabla rental e inventory
        INNER JOIN film f2 ON i2.film_id = f2.film_id                                       --Conectamos tabla film y title
        WHERE f2.title = 'SPARTACUS CHEAPER'                                          --Filtramos por la pelicula 'Spartacus Cheap' (mayúculas para obtener resultados)
      )
ORDER BY "apellido" ASC;                                                              --Ordenamos por apellido por orden alfabético