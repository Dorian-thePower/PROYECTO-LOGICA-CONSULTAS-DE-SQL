--4. Obtén las películas cuyo idioma coincide con el idioma original.

SELECT "title" 
FROM "film"
WHERE "language_id" = "original_language_id" ;