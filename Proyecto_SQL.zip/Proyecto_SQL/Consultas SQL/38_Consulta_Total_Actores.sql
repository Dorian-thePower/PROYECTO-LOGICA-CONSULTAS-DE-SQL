--38. Cuenta cuántos actores hay en la tabla “actorˮ.

SELECT 
     count("actor_id") AS "total_actores"
FROM "actor";