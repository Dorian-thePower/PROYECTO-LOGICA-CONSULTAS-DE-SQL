-- 36. Renombra la columna “first_nameˮ como Nombre y “last_nameˮ como Apellido.

SELECT 
     "first_name" AS "Nombre",
     "last_name"  AS "Apellido"
FROM "actor";