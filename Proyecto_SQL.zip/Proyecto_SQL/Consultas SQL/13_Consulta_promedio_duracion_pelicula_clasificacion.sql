--13. Encuentra el promedio de duración de las películas para cada clasificación de la tabla film y muestra la clasificación junto con el promedio de duración.

SELECT   
     "rating" AS "clasificacion",
     AVG("length") AS "promedio_duracion" 
FROM "film"
GROUP BY "rating" ;
