--10. Encuentra la mayor y menor duración de una película de nuestra BBDD.

SELECT 
    MIN("length") AS "duracion_minima",
    MAX("length") AS "duracion_maxima"
FROM "film";