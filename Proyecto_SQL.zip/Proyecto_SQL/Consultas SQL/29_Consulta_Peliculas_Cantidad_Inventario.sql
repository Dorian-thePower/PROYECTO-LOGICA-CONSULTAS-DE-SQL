--29. Obtener todas las películas y, si están disponibles en el inventario, mostrar la cantidad disponible.

SELECT                                                --Seleccionamos nombre de pelicula y total de peliculas en inventario
     "title",
     count(i.film_id ) AS "peliculas_inventario"      
FROM inventory i                                     --De la tabla inventory
FULL JOIN film f ON i.film_id = f.film_id            --Buscamos el foreign key film_id de la tabla inventory y film
GROUP BY "title"                                    --Agrupamos datos por title y ordenamos por pelicula_inventario descendiente.
ORDER BY "peliculas_inventario" DESC;